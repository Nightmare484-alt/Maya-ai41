package com.maya.assistant.ai

import com.maya.assistant.data.Role
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.util.Base64

/**
 * Minimal Google Gemini API (Google AI Studio key) client, no third-party HTTP library.
 * The key is sent in the `x-goog-api-key` header, never in the URL, so it can't leak via logs.
 */
class GeminiClient(
    private val baseUrl: String = "https://generativelanguage.googleapis.com/v1beta",
) : ChatClient {

    override suspend fun send(request: ChatRequest): String = withContext(Dispatchers.IO) {
        if (request.apiKey.isBlank()) throw ChatException(ChatError.MISSING_KEY)
        if (request.model.isBlank()) throw ChatException(ChatError.BAD_REQUEST)
        val url = "$baseUrl/models/${URLEncoder.encode(normalizeModelId(request.model), "UTF-8")}:generateContent"
        val text = call("POST", url, request.apiKey, buildBody(request), if (request.webSearch) 90_000 else 60_000)
        parseResponse(text)
    }

    override suspend fun listModels(apiKey: String): List<ModelInfo> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw ChatException(ChatError.MISSING_KEY)
        val all = mutableListOf<ModelInfo>()
        var token: String? = null
        var pages = 0
        do {
            val url = "$baseUrl/models?pageSize=1000" +
                (token?.let { "&pageToken=" + URLEncoder.encode(it, "UTF-8") } ?: "")
            val body = call("GET", url, apiKey, null, 20_000)
            all += parseModels(body)
            token = try { JSONObject(body).optString("nextPageToken").ifBlank { null } } catch (e: JSONException) { null }
        } while (token != null && ++pages < 5)
        all.distinctBy { it.id }.sortedBy { it.id }
    }

    private fun call(method: String, url: String, apiKey: String, body: String?, readTimeoutMs: Int): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15_000
            conn.readTimeout = readTimeoutMs
            conn.setRequestProperty("x-goog-api-key", apiKey)
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("content-type", "application/json")
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw ChatException(mapStatus(code, text))
            return text
        } catch (e: ChatException) {
            throw e
        } catch (e: SocketTimeoutException) {
            throw ChatException(ChatError.TIMEOUT, e)
        } catch (e: IOException) {
            throw ChatException(ChatError.NETWORK, e)
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        const val MAX_OUTPUT_TOKENS = 2048

        /** The list endpoint returns "models/gemini-x"; generate URLs want the bare id. */
        fun normalizeModelId(id: String) = id.trim().removePrefix("models/")

        fun buildBody(r: ChatRequest): String {
            val contents = JSONArray()
            r.history.forEach {
                contents.put(
                    JSONObject()
                        .put("role", if (it.role == Role.USER) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", it.text)))
                )
            }
            val parts = JSONArray()
            if (r.image != null) {
                parts.put(
                    JSONObject().put(
                        "inlineData",
                        JSONObject()
                            .put("mimeType", "image/jpeg")
                            .put("data", Base64.getEncoder().encodeToString(r.image))
                    )
                )
            }
            parts.put(JSONObject().put("text", r.userText))
            contents.put(JSONObject().put("role", "user").put("parts", parts))

            val root = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", r.system))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("maxOutputTokens", MAX_OUTPUT_TOKENS))
            if (r.webSearch) {
                root.put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            }
            return root.toString()
        }

        fun parseResponse(json: String): String {
            val candidates = try {
                JSONObject(json).optJSONArray("candidates")
            } catch (e: JSONException) {
                throw ChatException(ChatError.BAD_RESPONSE, e)
            }
            val parts = candidates?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                ?: throw ChatException(ChatError.BAD_RESPONSE)
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.optJSONObject(i) ?: continue
                if (p.optBoolean("thought", false)) continue // skip thinking summaries
                sb.append(p.optString("text"))
            }
            val out = sb.toString().trim()
            if (out.isEmpty()) throw ChatException(ChatError.BAD_RESPONSE)
            return out
        }

        /** Keeps models that can generate text via generateContent; drops audio/image/embedding-only ones. */
        fun parseModels(json: String): List<ModelInfo> {
            val arr: JSONArray? = try {
                JSONObject(json).optJSONArray("models")
            } catch (e: JSONException) {
                throw ChatException(ChatError.BAD_RESPONSE, e)
            }
            if (arr == null) return emptyList()
            val skip = listOf("tts", "image", "embedding", "audio", "live", "robotics", "computer-use", "aqa", "imagen", "veo")
            val out = mutableListOf<ModelInfo>()
            for (i in 0 until arr.length()) {
                val m = arr.optJSONObject(i) ?: continue
                val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                val canGenerate = (0 until methods.length()).any { methods.optString(it) == "generateContent" }
                val id = normalizeModelId(m.optString("name"))
                if (!canGenerate || id.isEmpty() || skip.any { id.contains(it) }) continue
                out += ModelInfo(id, m.optString("displayName").ifBlank { id })
            }
            return out
        }

        fun mapStatus(code: Int, body: String = ""): ChatError {
            // Google reports a bad key as HTTP 400 with reason API_KEY_INVALID, not 401.
            if (code == 400 && (body.contains("API_KEY_INVALID") || body.contains("API key not valid"))) {
                return ChatError.UNAUTHORIZED
            }
            return when (code) {
                400, 404, 413, 422 -> ChatError.BAD_REQUEST
                401, 403 -> ChatError.UNAUTHORIZED
                429 -> ChatError.RATE_LIMITED
                503 -> ChatError.OVERLOADED
                504 -> ChatError.TIMEOUT
                in 500..599 -> ChatError.SERVER
                else -> ChatError.UNKNOWN
            }
        }
    }
}
