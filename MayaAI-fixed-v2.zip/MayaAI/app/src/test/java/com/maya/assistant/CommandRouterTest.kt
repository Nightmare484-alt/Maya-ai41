package com.maya.assistant

import com.maya.assistant.actions.AppEntry
import com.maya.assistant.actions.AppMatcher
import com.maya.assistant.actions.CommandRouter
import com.maya.assistant.actions.LocalCommand
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CommandRouterTest {
    @Test fun opensApps() {
        assertEquals(LocalCommand.OpenApp("WhatsApp"), CommandRouter.route("Open WhatsApp"))
        assertEquals(LocalCommand.OpenApp("camera"), CommandRouter.route("hey Maya, please launch the camera app."))
    }

    @Test fun longOpenSentenceGoesToAi() {
        assertNull(CommandRouter.route("open a bank account and explain the fees"))
    }

    @Test fun youTube() {
        assertEquals(LocalCommand.YouTube("lofi beats"), CommandRouter.route("play lofi beats on YouTube"))
        assertEquals(LocalCommand.YouTube("kotlin tutorial"), CommandRouter.route("youtube search kotlin tutorial"))
    }

    @Test fun googleSearch() {
        assertEquals(LocalCommand.WebSearch("weather"), CommandRouter.route("google weather"))
    }

    @Test fun timers() {
        assertEquals(LocalCommand.Timer(600), CommandRouter.route("set a 10 minute timer"))
        assertEquals(LocalCommand.Timer(90), CommandRouter.route("timer for 90 seconds"))
        assertEquals(LocalCommand.Timer(7200), CommandRouter.route("set timer 2 hours"))
        assertNull(CommandRouter.route("set a timer"))
        assertNull(CommandRouter.route("set a timer for 500 hours"))
    }

    @Test fun remember() {
        assertEquals(LocalCommand.Remember("I like tea"), CommandRouter.route("Remember that I like tea!"))
    }

    @Test fun normalQuestionsAreNotCommands() {
        assertNull(CommandRouter.route("What is the capital of France?"))
        assertNull(CommandRouter.route(""))
    }

    @Test fun appMatcherPrefersExactThenPrefixThenContains() {
        val apps = listOf(AppEntry("YouTube Music", "a"), AppEntry("YouTube", "b"), AppEntry("My YouTube Tools", "c"))
        assertEquals("b", AppMatcher.best("youtube", apps)?.packageName)
        assertEquals("a", AppMatcher.best("youtube mu", apps)?.packageName)
        assertEquals("c", AppMatcher.best("tools", apps)?.packageName)
        assertNull(AppMatcher.best("spotify", apps))
        assertNull(AppMatcher.best("  ", apps))
    }
}
