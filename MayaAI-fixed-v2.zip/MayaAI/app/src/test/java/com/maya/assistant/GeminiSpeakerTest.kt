package com.maya.assistant

import com.maya.assistant.voice.GeminiSpeaker
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Base64

class GeminiSpeakerTest {
    @Test fun parsesPcmFromResponse() {
        val pcm = byteArrayOf(1, 2, 3, 4)
        val json = """{"candidates":[{"content":{"parts":[{"inlineData":{"mimeType":"audio/L16;rate=24000","data":"${Base64.getEncoder().encodeToString(pcm)}"}}]}}]}"""
        assertArrayEquals(pcm, GeminiSpeaker.parsePcm(json))
    }

    @Test(expected = IllegalStateException::class)
    fun noAudioThrowsSoFallbackRuns() {
        GeminiSpeaker.parsePcm("""{"candidates":[{"content":{"parts":[{"text":"hi"}]}}]}""")
    }

    @Test fun chunksLongTextOnSentences() {
        val text = (1..60).joinToString(" ") { "This is sentence number $it." }
        val chunks = GeminiSpeaker.chunk(text)
        assertTrue(chunks.size > 1 && chunks.all { it.length <= 700 })
    }
}

class GeminiSpeakerModelPickTest {
    @Test fun prefersStableFlashTtsOverPreview() {
        val json = """{"models":[
          {"name":"models/gemini-2.5-pro-preview-tts","supportedGenerationMethods":["generateContent"]},
          {"name":"models/gemini-2.5-flash-preview-tts","supportedGenerationMethods":["generateContent"]},
          {"name":"models/gemini-2.5-flash-tts","supportedGenerationMethods":["generateContent"]},
          {"name":"models/gemini-flash-latest","supportedGenerationMethods":["generateContent"]}]}"""
        org.junit.Assert.assertEquals("gemini-2.5-flash-tts", GeminiSpeaker.pickTtsModel(json))
    }
}
